# RecuperaTuCelu — Configuración de GitHub Actions para el APK release

## 1. Subí el proyecto a un repo de GitHub
Usá la carpeta `RecuperaTuCelu-android/` tal cual. Ya trae:
- `.github/workflows/release-apk.yml` → el workflow que compila y firma el APK
- `my-upload-key.jks` → tu keystore de firma (está en `.gitignore`, **no se va a subir a git**, es solo para que lo tengas a mano)
- `gradlew` / `gradlew.bat` → scripts del wrapper (el .jar del wrapper se genera automáticamente en cada build de CI)

```bash
cd RecuperaTuCelu-android
git init
git add .
git commit -m "Proyecto inicial RecuperaTuCelu"
git branch -M main
git remote add origin https://github.com/TU_USUARIO/TU_REPO.git
git push -u origin main
```

## 2. Cargá 3 secrets en el repo de GitHub
En tu repo: **Settings → Secrets and variables → Actions → New repository secret**

| Nombre del secret | Valor |
|---|---|
| `ANDROID_KEYSTORE_BASE64` | ver abajo (todo el bloque, sin espacios ni saltos) |
| `ANDROID_STORE_PASSWORD` | `msbv0JzG5ApHN1wYRV1kro7S` |
| `ANDROID_KEY_PASSWORD` | `msbv0JzG5ApHN1wYRV1kro7S` |

### Valor de ANDROID_KEYSTORE_BASE64
```
MIIK1AIBAzCCCn4GCSqGSIb3DQEHAaCCCm8EggprMIIKZzCCBa4GCSqGSIb3DQEHAaCCBZ8EggWbMIIFlzCCBZMGCyqGSIb3DQEMCgECoIIFQDCCBTwwZgYJKoZIhvcNAQUNMFkwOAYJKoZIhvcNAQUMMCsEFAdH900UJG9gMqHZEw92airfI3SeAgInEAIBIDAMBggqhkiG9w0CCQUAMB0GCWCGSAFlAwQBKgQQ/y3mN+FSAPic0VL7uLnmvQSCBNDgk4IKWhCjsh+tJbNV6zaJRXA3aJmteSIANov6rjDTEkwuKLJkVh1XXz2aoi4D/w+ent6b/vI9p06Q5M4E1/3nZiLoo7noxk3N2O9BGO19lXLtzrQPNisUOXsIcI1WG5P5dHyJbcnccFk44IVHDG6AQFo1I2hjVtHPxmkG16MyyC20KvPg2Af9H2tEEAumks3tg4NEznZrNseE00i0Wnh7lcFvIXxhLEnCf7sbGWxyUfuNCpbxBQ5Wo5BGmzl8brML3g5PiKdSY75tXvfa8uc/JD0jeYbGblzYBT/+7PtI7pYVG/obiuwhAafuWE6F3KW7qAlu+buo5B9QSZFT/E5UBPc6oEgsgHWyuaKgyegveg9bBarZmFF6D95epppja7Ic8sRHYFfpKebbqHSc8UONlaj0yDHBRPEOfsYStvjO0Xzrjh8ZMPVwVw1VTMEuXpU0xGlxgSJvMxNdGrTFiOESKOtFM3BVIBv/bP2yKowTXDOUDJUT4MTV05hCTeZ7Iv9ZeOJ9NF4ZPEZWBM0xPE4M8vBI9jbTRK1D7/3TStZYcBJ+BDqoY8h6n4fvjRiafQy/yukOYv08XSYEv0HlnWiVuOWd7816LxnrBAyHEM4v3xjBs+F3sHWRdabgU9ZTViSW616qUqC69b2ztCP7ETDl1UrSsNKoY37cy11Kn/mLL8/pwIEEIJapZIpmFU6SvPRSvCYBbnouDHaT90+k03ZMZD6NnZf56HBSpTHfu5BM77UiGMuiovqvhLIefId3bSL96fa/RK7VeLtfa+OH6P7ls/ofSoQQCWL5dRA9+zZlNcuMdQtn2L5ecR7ttXhZUiVy8lE1VsAVZ0c/RKwN1MAT70C8chkUW/y58dKcCEZ3Cm2xGa3lqtuW/70SyF9lXplxHNs6v/QM7CiTXEMpLeghj49nB60BWqI9kW0Z2pYD2avWh5V9nmgD1XECTsePUmemRheDqgZIt3umPa9K4hd0ltoHNu+vGiYny6ztui5blbXCcpwLmXF+w+8CQqCInPzQ6FAHj+0YapW0m+MPJET5FbsJ9ZnXCYM4bDY7Fw+0KCVEn2nVa88XJ3hfc4OwVd8gfT59VZM3NM1gH+94O564cVo7Ws8s+8fypleGZonRmirEQsw56Y4iMfj6EB+lO+VHhJUFo8YZF+e6P+ssGtxQa07Vh10uUQEybzf62Essmzb+t1vZH3BibbGqiBegdBE01//25yYtdub8kywcZDbRMbGCfPugSMOKm695iRyUIzOpzzqbB1e+CxtRP5RAeHZrRavkTyupcdBNs6XRWD9JGj+BVSwOk9WBbD0DgmN/KH223J1Iuo+MmEsrMJwITUL3QTWqMuCD+QAqFCxENzTFXXUMasepHElME61Y5tkSSfZHizPSpgsfigb3tMoGs7f2LqPv3KPZlqsZ6jXyqgPK35N5Eal161lC6LA9ICBeOB9Jxroio3H9dfgzWqdcsASwz9MCIsDlrltflS9HVhMBAkdyY0bWw9nZIJdiQTbRVtnPVXOUtQtGp2erChRX5hrqQkSwbB3CNH5SWF/QeuLWwjUVyVmwDcrXzdV8DthtwWaSYbwFWj1boBSZF6EULs8BjV+vGHcqyF5C2Q+r7lp+/SKP0iwAlLNqetpDqFI1XjFAMBsGCSqGSIb3DQEJFDEOHgwAdQBwAGwAbwBhAGQwIQYJKoZIhvcNAQkVMRQEElRpbWUgMTc4ODU1OTYyMzcyOTCCBLEGCSqGSIb3DQEHBqCCBKIwggSeAgEAMIIElwYJKoZIhvcNAQcBMGYGCSqGSIb3DQEFDTBZMDgGCSqGSIb3DQEFDDArBBRr+NQtlx8Uls/PXLY0P2YHtnx3rgICJxACASAwDAYIKoZIhvcNAgkFADAdBglghkgBZQMEASoEEGAmMPF9HNGafMSqOkQM4qKAggQgcCca/rwNnq2ZT5dztLs1UqbmnVHfLIFi7Ierld18AG7I/A/CwTraTv2TVMU9cA5ogCuMarQlaBwANT/pvYmk9EJIVPVKFcOxwSUjRA+TgZWiVt1uN53G2VIy2FLTArlbHtfKiEeIT268jZZAD204OOKkwXSUhIrv5kam2lJxFctFZro5rxVhbPGjsWMLhDBCu9stiHHQwRHVitSMP6TfNy4Q0BUBimVY1Rn0Mn5HZoBb2eBp/m2ZdbA7aAwmVvRl6A1qoJIbEBkYWbYsNG/AQdxjz9CJrP9PzYZ008OJFxm8Usmp8QeM7p2spbU0FE6kV80DnMA5Abi7DUC76e2l3Hlp+al2S+XHIvMZMobjf61s0VXYlmW2Z9kYJ1b264YlZB0zoQXvCVwhkVb0uqCieagNaCc2QFONq+Jk+iqNAWNL0rWgqZ5w4yDpuQj+6bsDZY8yJAgzdrWdc1ZuDZxY4qBUrvTFzjBUgKMVUYnX2xGP0Lxvnwx7XosOmRy60FE4C9dVdWAPnZXHy1PfWi7I0EnG9vMWA8mxXJ3tt6UH0jzUU1EHBZ0vbsm6E5AyiWL97RdmEXawt1d5ZfxxoINaF0eyGr9vJ9lelrNSstT9FkJB8QjwaIgQkGEt36zgNIAj+dUqrwsiZReREbPi0OaZAna/Fzo+1X/t69fvdLYTrFsu4raHijfjTcgNrTsWuK/OQjGELbaFxLBeJqvl9TcmwL8oHaJwat/jBizG5unN3l1RlDkuZjxfYaXuTRLTm02yopGa3R1KF6hE2iGLARSrwzuRsHJxtG9DOtCVQ2X/dQnT8m2z/iPItxrBE2xnkycPC57eY3e9xOEcnSX6E+iZ/Fk1jw3iF0BXD5MCgq6v7Sk1bynhJzefRiChLKMtdhZV3NExKnnJntLl0nvELRM08ACjMQSiXSjPiAgp+sfvuX95EXi0ZGdN/pEK0bn8bQMDYfffRotxmBDNMJC4jRbdiLNCiZvgRPCxYIL7WJgsqeRUs8pk2E7ox/LI+XqoxAlm6w9FtJO47heLZqs9N4/8LET7w9XoNxNNn+V4xLk1IRuBKogFDYBk+ptCO0dz3mjlSny7AbTvARjz93IKgeQ07KXizZicNs8flqLUqstNpb+UC8ZEPnVjoa7YuxdRb9P+wvu05e30P3mRD5+57Y5i/KfaQqPByJKE0qK26hbA8xWfhWzSabSrID7eBcw0dm2OTbKbsSSBFf1l8Ogpmh5RJNKftAiDf2QSu2LolqyYlslHNQTCSOmyw16wPrmoGjKb2AFq5SZyeXpuWnM/55s+ciyXcxrvyEM2NUg/yrX4PNQeAx472e2nI+nbnaUI3LXrSSF0X36MFM7XYkpNitPYj0e51lsWkDq98kSvZFxs6YBnmXOJ5g5J+WhXqvK1kIbUME0wMTANBglghkgBZQMEAgEFAAQghJ6Gg4GvlGE6O/oBV9Dlyd2sx8oOtcrKqCw+nrPyBqIEFLbK11UMfa+NIIjpMLuXGVuIbU1mAgInEA==
```

## 3. Ejecutá el workflow
Con hacer push a `main` ya se dispara solo. También podés lanzarlo a mano desde
**Actions → Build Release APK → Run workflow**.

Al terminar, el APK queda como **artifact** descargable llamado
`RecuperaTuCelu-release-apk` en la página de esa ejecución (pestaña *Actions*).

## 4. Guardá el keystore y las contraseñas en un lugar seguro
- Alias: `upload`
- Contraseña (store y key): `msbv0JzG5ApHN1wYRV1kro7S`
- Validez: 10.000 días (~27 años)

**Importante:** si perdés este keystore o la contraseña, no vas a poder publicar
actualizaciones de la app con el mismo `applicationId` en Google Play — tendrías
que publicarla como app nueva. Hacé una copia de `my-upload-key.jks` fuera del
repo (gestor de contraseñas, backup cifrado, etc.).

## 5. Sobre Firebase
El proyecto sigue teniendo las dependencias de Firebase (Auth, Firestore) en el
código, pero **no se incluyó `google-services.json`**. El build no falla por eso
(`missingGoogleServicesStrategy = WARN`), pero cualquier llamada real a Firebase
en runtime no va a funcionar hasta que agregues ese archivo en `app/`. El código
ya tiene guardas (`FirebaseApp.getApps(context).isNotEmpty()`) que evitan crashear
por esto.

## 6. Después de usar este instructivo
Borrá este archivo (o al menos la sección de secrets) una vez que hayas cargado
los secrets en GitHub — tiene una contraseña y un keystore en texto plano.
