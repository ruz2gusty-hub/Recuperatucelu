package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Geometric Balance Design System Palette
val DarkBackground = Color(0xFF1C1B1F)       // Body background
val DarkSurface = Color(0xFF2B2930)          // Surface / Cards / Header bar
val DarkSurfaceVariant = Color(0xFF4A4458)   // Container / Pill / Avatar badge
val DarkSurfaceHighlight = Color(0xFF36343B) // Active / hover surface

// Primary Accent (Lavender / Violet)
val PrimaryCyan = Color(0xFFD0BCFF)          // Accent violet #D0BCFF
val PrimaryCyanLight = Color(0xFFE8DEF8)     // Light violet tint
val PrimaryCyanDark = Color(0xFF381E72)      // Deep violet #381E72
val OnPrimaryDark = Color(0xFF381E72)        // On-primary text/icon color

// Secondary & Success (Geometric Mint / Emerald)
val SecondaryEmerald = Color(0xFFA8E6CF)      // Soft mint
val SecondaryEmeraldDark = Color(0xFF1E3A2F)  // Dark forest container
val OnSecondaryDark = Color(0xFF003822)

// Alerts & Badges
val AccentAmber = Color(0xFFFFD180)          // Warm geometric amber
val AccentOrange = Color(0xFFFFB74D)
val AccentRed = Color(0xFFF2B8B5)            // Soft red text
val BadgeLostBg = Color(0xFF8C1D18)          // Geometric red badge background
val BadgeLostText = Color(0xFFF9DEDC)        // Geometric red badge text
val BadgeRecoveredBg = Color(0xFF1E3A2F)     // Geometric recovered badge background
val BadgeRecoveredText = Color(0xFFA8E6CF)   // Geometric recovered badge text

// Text & Monospace
val TextPrimary = Color(0xFFE6E1E5)          // Primary text #E6E1E5
val TextSecondary = Color(0xFF938F99)        // Secondary text #938F99
val TextMuted = Color(0xFF79747E)            // Muted text

// Outlines & Borders
val OutlineColor = Color(0xFF49454F)         // Border #49454F
val OutlineVariantColor = Color(0xFF36343B)  // Border variant #36343B

