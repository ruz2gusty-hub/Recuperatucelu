package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = PrimaryCyan,
    onPrimary = OnPrimaryDark,
    primaryContainer = DarkSurfaceVariant,
    onPrimaryContainer = PrimaryCyanLight,

    secondary = SecondaryEmerald,
    onSecondary = OnSecondaryDark,
    secondaryContainer = SecondaryEmeraldDark,
    onSecondaryContainer = Color(0xFFD1FAE5),

    tertiary = AccentAmber,
    onTertiary = Color(0xFF451A03),
    tertiaryContainer = Color(0xFF78350F),
    onTertiaryContainer = Color(0xFFFEF3C7),

    background = DarkBackground,
    onBackground = TextPrimary,

    surface = DarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = TextSecondary,

    outline = OutlineColor,
    outlineVariant = OutlineVariantColor,

    error = AccentRed,
    onError = Color(0xFF601410)
)

@Composable
fun RecuperaTuCeluTheme(
    content: @Composable () -> Unit
) {
    // Dark mode by default as per request
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    RecuperaTuCeluTheme(content = content)
}
