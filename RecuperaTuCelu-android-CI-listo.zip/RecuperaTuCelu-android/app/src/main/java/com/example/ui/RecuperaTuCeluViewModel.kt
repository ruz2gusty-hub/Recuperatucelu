package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppUser
import com.example.data.AuthRepository
import com.example.data.CelularesRepository
import com.example.model.Celular
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface UiMessage {
    data class Success(val message: String) : UiMessage
    data class Error(val message: String) : UiMessage
}

class RecuperaTuCeluViewModel(application: Application) : AndroidViewModel(application) {

    val authRepo = AuthRepository(application)
    val celularesRepo = CelularesRepository(application)

    // Auth State
    private val _currentUser = MutableStateFlow<AppUser?>(authRepo.getCurrentUser())
    val currentUser: StateFlow<AppUser?> = _currentUser.asStateFlow()

    val isCloudConnected = authRepo.isCloudConnected

    val authEmail = MutableStateFlow("")
    val authPassword = MutableStateFlow("")
    val isSignUpMode = MutableStateFlow(false)
    val authError = MutableStateFlow<String?>(null)
    val isAuthLoading = MutableStateFlow(false)

    // Phone List & Search
    private val _celularesList = MutableStateFlow<List<Celular>>(emptyList())
    val celularesList: StateFlow<List<Celular>> = _celularesList.asStateFlow()

    val searchQuery = MutableStateFlow("")
    val selectedFilter = MutableStateFlow("Todos") // "Todos", "Perdidos", "Recuperados", "Mis Reportes"

    val filteredCelulares: StateFlow<List<Celular>> = combine(
        _celularesList,
        searchQuery,
        selectedFilter,
        _currentUser
    ) { list, query, filter, user ->
        var result = list

        if (query.isNotBlank()) {
            val q = query.trim().lowercase()
            result = result.filter {
                it.imei.contains(q, ignoreCase = true) ||
                it.marca.lowercase().contains(q) ||
                it.modelo.lowercase().contains(q) ||
                it.color.lowercase().contains(q)
            }
        }

        when (filter) {
            "Perdidos" -> result.filter { it.estado.equals("Perdido", ignoreCase = true) }
            "Recuperados" -> result.filter { it.estado.equals("Recuperado", ignoreCase = true) }
            "Mis Reportes" -> {
                val userEmail = user?.email?.lowercase().orEmpty()
                result.filter { it.usuarioEmail.lowercase() == userEmail }
            }
            else -> result
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Form to Add New Phone
    val showAddDialog = MutableStateFlow(false)
    val formMarca = MutableStateFlow("")
    val formModelo = MutableStateFlow("")
    val formImei = MutableStateFlow("")
    val formColor = MutableStateFlow("")
    val formContacto = MutableStateFlow("")
    val formDescripcion = MutableStateFlow("")
    val isSavingPhone = MutableStateFlow(false)
    val formError = MutableStateFlow<String?>(null)

    // IMEI Verification Sheet
    val showImeiCheckDialog = MutableStateFlow(false)
    val imeiCheckInput = MutableStateFlow("")
    val imeiCheckResult = MutableStateFlow<Celular?>(null)
    val hasCheckedImei = MutableStateFlow(false)
    val isCheckingImei = MutableStateFlow(false)

    // Selected phone for details
    val selectedPhone = MutableStateFlow<Celular?>(null)

    // Toast / Snackbar notifications
    val uiMessage = MutableStateFlow<UiMessage?>(null)

    init {
        viewModelScope.launch {
            celularesRepo.getCelularesFlow().collect { list ->
                _celularesList.value = list
            }
        }
    }

    // --- Authentication Actions ---

    fun login() {
        val email = authEmail.value.trim()
        val password = authPassword.value
        if (email.isEmpty() || password.isEmpty()) {
            authError.value = "Ingresa tu correo y contraseña"
            return
        }

        viewModelScope.launch {
            isAuthLoading.value = true
            authError.value = null
            val result = authRepo.signIn(email, password)
            isAuthLoading.value = false
            result.fold(
                onSuccess = { user ->
                    _currentUser.value = user
                    authEmail.value = ""
                    authPassword.value = ""
                },
                onFailure = { err ->
                    authError.value = translateAuthError(err.message ?: "Error al iniciar sesión")
                }
            )
        }
    }

    fun register() {
        val email = authEmail.value.trim()
        val password = authPassword.value
        if (email.isEmpty() || password.isEmpty()) {
            authError.value = "Completa todos los campos"
            return
        }
        if (password.length < 6) {
            authError.value = "La contraseña debe tener al menos 6 caracteres"
            return
        }

        viewModelScope.launch {
            isAuthLoading.value = true
            authError.value = null
            val result = authRepo.signUp(email, password)
            isAuthLoading.value = false
            result.fold(
                onSuccess = { user ->
                    _currentUser.value = user
                    authEmail.value = ""
                    authPassword.value = ""
                    uiMessage.value = UiMessage.Success("¡Cuenta creada exitosamente!")
                },
                onFailure = { err ->
                    authError.value = translateAuthError(err.message ?: "Error al registrar cuenta")
                }
            )
        }
    }

    fun quickDemoLogin() {
        viewModelScope.launch {
            isAuthLoading.value = true
            val result = authRepo.signIn("usuario.demo@recuperatucelu.com", "demo123456")
            isAuthLoading.value = false
            result.fold(
                onSuccess = { user ->
                    _currentUser.value = user
                },
                onFailure = {
                    val fallback = AppUser("demo_user", "usuario.demo@recuperatucelu.com", "Usuario Demo")
                    _currentUser.value = fallback
                }
            )
        }
    }

    fun logout() {
        authRepo.signOut()
        _currentUser.value = null
    }

    // --- Phone Management Actions ---

    fun openAddDialog() {
        formMarca.value = ""
        formModelo.value = ""
        formImei.value = ""
        formColor.value = ""
        formContacto.value = ""
        formDescripcion.value = ""
        formError.value = null
        showAddDialog.value = true
    }

    fun saveNewPhone() {
        val marca = formMarca.value.trim()
        val modelo = formModelo.value.trim()
        val imei = formImei.value.trim().filter { it.isDigit() }
        val color = formColor.value.trim()
        val contacto = formContacto.value.trim()
        val descripcion = formDescripcion.value.trim()

        if (marca.isEmpty()) {
            formError.value = "Ingresa la marca del celular"
            return
        }
        if (modelo.isEmpty()) {
            formError.value = "Ingresa el modelo del celular"
            return
        }
        if (imei.length != 15) {
            formError.value = "El IMEI debe tener exactamente 15 dígitos (actual: ${imei.length})"
            return
        }
        if (color.isEmpty()) {
            formError.value = "Ingresa el color del celular"
            return
        }
        if (contacto.isEmpty()) {
            formError.value = "Ingresa un número o email de contacto"
            return
        }

        viewModelScope.launch {
            isSavingPhone.value = true
            formError.value = null

            val nuevoCelular = Celular(
                marca = marca,
                modelo = modelo,
                imei = imei,
                color = color,
                contacto = contacto,
                descripcion = descripcion,
                usuarioEmail = _currentUser.value?.email ?: "anonimo@recuperatucelu.com",
                fechaRegistro = System.currentTimeMillis(),
                estado = "Perdido"
            )

            val result = celularesRepo.agregarCelular(nuevoCelular)
            isSavingPhone.value = false

            result.fold(
                onSuccess = {
                    showAddDialog.value = false
                    uiMessage.value = UiMessage.Success("Reporte de $marca $modelo registrado correctamente")
                },
                onFailure = {
                    formError.value = "No se pudo guardar el reporte: ${it.message}"
                }
            )
        }
    }

    fun checkImei() {
        val query = imeiCheckInput.value.trim().filter { it.isDigit() }
        if (query.isEmpty()) return

        viewModelScope.launch {
            isCheckingImei.value = true
            val results = celularesRepo.buscarPorImei(query)
            isCheckingImei.value = false
            hasCheckedImei.value = true
            imeiCheckResult.value = results.firstOrNull { it.imei == query } ?: results.firstOrNull()
        }
    }

    fun markAsRecovered(celularId: String) {
        viewModelScope.launch {
            celularesRepo.marcarComoRecuperado(celularId)
            uiMessage.value = UiMessage.Success("¡Estado actualizado a Recuperado!")
            if (selectedPhone.value?.id == celularId) {
                selectedPhone.value = selectedPhone.value?.copy(estado = "Recuperado")
            }
        }
    }

    fun clearUiMessage() {
        uiMessage.value = null
    }

    private fun translateAuthError(error: String): String {
        return when {
            error.contains("password", ignoreCase = true) -> "Contraseña incorrecta o débil (mínimo 6 caracteres)."
            error.contains("user-not-found", ignoreCase = true) -> "No existe usuario registrado con este correo."
            error.contains("email-already-in-use", ignoreCase = true) -> "Ya existe una cuenta con este correo."
            error.contains("badly formatted", ignoreCase = true) -> "El formato de correo no es válido."
            error.contains("network", ignoreCase = true) -> "Error de red. Verifica tu conexión a internet."
            else -> error
        }
    }
}
