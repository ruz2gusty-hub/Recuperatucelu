package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Dialpad
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.DialogProperties
import com.example.ui.RecuperaTuCeluViewModel
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.OnPrimaryDark
import com.example.ui.theme.OutlineColor
import com.example.ui.theme.PrimaryCyan
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun AddPhoneDialog(viewModel: RecuperaTuCeluViewModel) {
    val marca by viewModel.formMarca.collectAsState()
    val modelo by viewModel.formModelo.collectAsState()
    val imei by viewModel.formImei.collectAsState()
    val color by viewModel.formColor.collectAsState()
    val contacto by viewModel.formContacto.collectAsState()
    val descripcion by viewModel.formDescripcion.collectAsState()
    val error by viewModel.formError.collectAsState()
    val isSaving by viewModel.isSavingPhone.collectAsState()

    val focusManager = LocalFocusManager.current
    val scrollState = rememberScrollState()

    val commonBrands = listOf("Samsung", "Apple", "Xiaomi", "Motorola", "Huawei", "Realme")

    AlertDialog(
        onDismissRequest = { if (!isSaving) viewModel.showAddDialog.value = false },
        properties = DialogProperties(usePlatformDefaultWidth = false),
        modifier = Modifier
            .fillMaxWidth(0.95f)
            .padding(16.dp),
        containerColor = DarkSurface,
        shape = RoundedCornerShape(24.dp),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.PhoneAndroid,
                        contentDescription = null,
                        tint = PrimaryCyan,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Reportar Celular",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Medium,
                            letterSpacing = 0.5.sp
                        ),
                        color = TextPrimary
                    )
                }
                IconButton(
                    onClick = { viewModel.showAddDialog.value = false },
                    enabled = !isSaving
                ) {
                    Icon(Icons.Default.Close, contentDescription = "Cerrar", tint = TextSecondary)
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(scrollState)
            ) {
                Text(
                    text = "Registra los datos para que quien lo encuentre o verifique pueda contactarte.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Brand quick suggestions
                Text(
                    text = "Marca:",
                    style = MaterialTheme.typography.labelMedium,
                    color = TextPrimary
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    commonBrands.forEach { brand ->
                        FilterChip(
                            selected = marca.equals(brand, ignoreCase = true),
                            onClick = { viewModel.formMarca.value = brand },
                            label = { Text(brand) },
                            shape = CircleShape,
                            colors = FilterChipDefaults.filterChipColors(
                                containerColor = DarkSurface,
                                labelColor = TextSecondary,
                                selectedContainerColor = DarkSurfaceVariant,
                                selectedLabelColor = PrimaryCyan
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = marca.equals(brand, ignoreCase = true),
                                borderColor = if (marca.equals(brand, ignoreCase = true)) PrimaryCyan else OutlineColor
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Marca Field
                OutlinedTextField(
                    value = marca,
                    onValueChange = {
                        viewModel.formMarca.value = it
                        viewModel.formError.value = null
                    },
                    label = { Text("Marca *") },
                    placeholder = { Text("Ej: Samsung, Apple, Motorola", color = TextSecondary) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                    keyboardActions = KeyboardActions(onNext = { focusManager.moveFocus(FocusDirection.Down) }),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("marca_input"),
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = DarkSurface,
                        unfocusedContainerColor = DarkSurface,
                        focusedBorderColor = PrimaryCyan,
                        unfocusedBorderColor = OutlineColor,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Modelo Field
                OutlinedTextField(
                    value = modelo,
                    onValueChange = {
                        viewModel.formModelo.value = it
                        viewModel.formError.value = null
                    },
                    label = { Text("Modelo *") },
                    placeholder = { Text("Ej: Galaxy S23, iPhone 14 Pro", color = TextSecondary) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                    keyboardActions = KeyboardActions(onNext = { focusManager.moveFocus(FocusDirection.Down) }),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("modelo_input"),
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = DarkSurface,
                        unfocusedContainerColor = DarkSurface,
                        focusedBorderColor = PrimaryCyan,
                        unfocusedBorderColor = OutlineColor,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                // IMEI Field
                val cleanImei = imei.filter { it.isDigit() }
                OutlinedTextField(
                    value = imei,
                    onValueChange = {
                        val digits = it.filter { ch -> ch.isDigit() }
                        if (digits.length <= 15) {
                            viewModel.formImei.value = digits
                            viewModel.formError.value = null
                        }
                    },
                    label = { Text("IMEI (15 dígitos) *") },
                    placeholder = { Text("864209041234567", color = TextSecondary) },
                    leadingIcon = {
                        Icon(Icons.Default.Dialpad, contentDescription = null, tint = TextSecondary)
                    },
                    supportingText = {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Marca *#06# en tu teléfono para ver el IMEI", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                            Text("${cleanImei.length}/15", color = if (cleanImei.length == 15) PrimaryCyan else TextSecondary)
                        }
                    },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Number,
                        imeAction = ImeAction.Next
                    ),
                    keyboardActions = KeyboardActions(onNext = { focusManager.moveFocus(FocusDirection.Down) }),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("imei_input"),
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = DarkSurface,
                        unfocusedContainerColor = DarkSurface,
                        focusedBorderColor = PrimaryCyan,
                        unfocusedBorderColor = OutlineColor,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Color Field
                OutlinedTextField(
                    value = color,
                    onValueChange = {
                        viewModel.formColor.value = it
                        viewModel.formError.value = null
                    },
                    label = { Text("Color *") },
                    placeholder = { Text("Ej: Negro, Azul medianoche, Plata", color = TextSecondary) },
                    leadingIcon = {
                        Icon(Icons.Default.ColorLens, contentDescription = null, tint = TextSecondary)
                    },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                    keyboardActions = KeyboardActions(onNext = { focusManager.moveFocus(FocusDirection.Down) }),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("color_input"),
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = DarkSurface,
                        unfocusedContainerColor = DarkSurface,
                        focusedBorderColor = PrimaryCyan,
                        unfocusedBorderColor = OutlineColor,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Contacto Field
                OutlinedTextField(
                    value = contacto,
                    onValueChange = {
                        viewModel.formContacto.value = it
                        viewModel.formError.value = null
                    },
                    label = { Text("Contacto para devolución *") },
                    placeholder = { Text("Teléfono, WhatsApp o Email alternativo", color = TextSecondary) },
                    leadingIcon = {
                        Icon(Icons.Default.Phone, contentDescription = null, tint = TextSecondary)
                    },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Phone,
                        imeAction = ImeAction.Next
                    ),
                    keyboardActions = KeyboardActions(onNext = { focusManager.moveFocus(FocusDirection.Down) }),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("contacto_input"),
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = DarkSurface,
                        unfocusedContainerColor = DarkSurface,
                        focusedBorderColor = PrimaryCyan,
                        unfocusedBorderColor = OutlineColor,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Optional Description / Location
                OutlinedTextField(
                    value = descripcion,
                    onValueChange = { viewModel.formDescripcion.value = it },
                    label = { Text("Detalles o lugar de pérdida (opcional)") },
                    placeholder = { Text("Ej: Olvidado en taxi centro, funda con sticker...", color = TextSecondary) },
                    leadingIcon = {
                        Icon(Icons.Default.Description, contentDescription = null, tint = TextSecondary)
                    },
                    maxLines = 3,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus() }),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("descripcion_input"),
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = DarkSurface,
                        unfocusedContainerColor = DarkSurface,
                        focusedBorderColor = PrimaryCyan,
                        unfocusedBorderColor = OutlineColor,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                // Error Message Display
                AnimatedVisibility(visible = error != null) {
                    Surface(
                        color = MaterialTheme.colorScheme.error.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 12.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Default.Warning,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = error ?: "",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { viewModel.saveNewPhone() },
                enabled = !isSaving,
                colors = ButtonDefaults.buttonColors(
                    containerColor = PrimaryCyan,
                    contentColor = OnPrimaryDark
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.testTag("btn_guardar_reporte")
            ) {
                if (isSaving) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(18.dp),
                        color = OnPrimaryDark,
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Guardando...")
                } else {
                    Text("Publicar Reporte", fontWeight = FontWeight.Bold)
                }
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = { viewModel.showAddDialog.value = false },
                enabled = !isSaving,
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, OutlineColor)
            ) {
                Text("Cancelar", color = TextSecondary)
            }
        }
    )
}
