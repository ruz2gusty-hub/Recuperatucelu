package com.example.data

import android.content.Context
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

data class AppUser(
    val uid: String,
    val email: String,
    val displayName: String = ""
)

class AuthRepository(private val context: Context) {

    private val prefs = context.getSharedPreferences("recupera_auth_prefs", Context.MODE_PRIVATE)

    private val _localUser = MutableStateFlow<AppUser?>(loadLocalUser())
    val localUser = _localUser.asStateFlow()

    private val isFirebaseAvailable: Boolean
        get() = try {
            FirebaseApp.getApps(context).isNotEmpty()
        } catch (e: Throwable) {
            false
        }

    val isCloudConnected: Boolean
        get() = isFirebaseAvailable

    fun getCurrentUser(): AppUser? {
        if (isFirebaseAvailable) {
            val fbUser = try {
                FirebaseAuth.getInstance().currentUser
            } catch (e: Throwable) {
                null
            }
            if (fbUser != null) {
                return AppUser(
                    uid = fbUser.uid,
                    email = fbUser.email ?: "",
                    displayName = fbUser.displayName ?: fbUser.email?.substringBefore("@") ?: ""
                )
            }
        }
        return _localUser.value
    }

    fun authStateFlow(): Flow<AppUser?> = callbackFlow {
        if (isFirebaseAvailable) {
            try {
                val auth = FirebaseAuth.getInstance()
                val listener = FirebaseAuth.AuthStateListener { fbAuth ->
                    val user = fbAuth.currentUser
                    if (user != null) {
                        trySend(
                            AppUser(
                                uid = user.uid,
                                email = user.email ?: "",
                                displayName = user.displayName ?: user.email?.substringBefore("@") ?: ""
                            )
                        )
                    } else {
                        trySend(_localUser.value)
                    }
                }
                auth.addAuthStateListener(listener)
                awaitClose { auth.removeAuthStateListener(listener) }
                return@callbackFlow
            } catch (e: Throwable) {
                // fallback to local below
            }
        }

        val job = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Default).run {
            // Emit local user updates
        }
        trySend(_localUser.value)
        awaitClose { }
    }

    suspend fun signIn(email: String, password: String):Result<AppUser> {
        if (isFirebaseAvailable) {
            return try {
                val result = FirebaseAuth.getInstance().signInWithEmailAndPassword(email, password).await()
                val user = result.user
                if (user != null) {
                    val appUser = AppUser(
                        uid = user.uid,
                        email = user.email ?: email,
                        displayName = user.displayName ?: email.substringBefore("@")
                    )
                    Result.success(appUser)
                } else {
                    Result.failure(Exception("Error al autenticar usuario."))
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

        // Offline / Demo fallback when google-services.json is not configured
        if (email.isBlank() || password.isBlank()) {
            return Result.failure(Exception("Por favor ingresa correo y contraseña."))
        }
        if (password.length < 6) {
            return Result.failure(Exception("La contraseña debe tener al menos 6 caracteres."))
        }

        val appUser = AppUser(
            uid = "local_" + email.hashCode(),
            email = email,
            displayName = email.substringBefore("@")
        )
        saveLocalUser(appUser)
        _localUser.value = appUser
        return Result.success(appUser)
    }

    suspend fun signUp(email: String, password: String): Result<AppUser> {
        if (isFirebaseAvailable) {
            return try {
                val result = FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, password).await()
                val user = result.user
                if (user != null) {
                    val appUser = AppUser(
                        uid = user.uid,
                        email = user.email ?: email,
                        displayName = email.substringBefore("@")
                    )
                    Result.success(appUser)
                } else {
                    Result.failure(Exception("Error al registrar usuario."))
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

        // Offline / Demo fallback
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            return Result.failure(Exception("Ingresa un correo electrónico válido."))
        }
        if (password.length < 6) {
            return Result.failure(Exception("La contraseña debe tener al menos 6 caracteres."))
        }

        val appUser = AppUser(
            uid = "local_" + email.hashCode(),
            email = email,
            displayName = email.substringBefore("@")
        )
        saveLocalUser(appUser)
        _localUser.value = appUser
        return Result.success(appUser)
    }

    fun signOut() {
        if (isFirebaseAvailable) {
            try {
                FirebaseAuth.getInstance().signOut()
            } catch (e: Throwable) {
                // ignore
            }
        }
        clearLocalUser()
        _localUser.value = null
    }

    private fun loadLocalUser(): AppUser? {
        val email = prefs.getString("user_email", null) ?: return null
        val uid = prefs.getString("user_uid", "local_user") ?: "local_user"
        val name = prefs.getString("user_name", email.substringBefore("@")) ?: email.substringBefore("@")
        return AppUser(uid = uid, email = email, displayName = name)
    }

    private fun saveLocalUser(user: AppUser) {
        prefs.edit()
            .putString("user_email", user.email)
            .putString("user_uid", user.uid)
            .putString("user_name", user.displayName)
            .apply()
    }

    private fun clearLocalUser() {
        prefs.edit().clear().apply()
    }
}
