package com.example.data

import android.content.Context
import android.util.Log
import com.example.model.Celular
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import org.json.JSONArray
import org.json.JSONObject

class CelularesRepository(private val context: Context) {

    private val prefs = context.getSharedPreferences("recupera_celulares_prefs", Context.MODE_PRIVATE)

    private val _localCelulares = MutableStateFlow<List<Celular>>(loadStoredPhones())
    val localCelulares = _localCelulares.asStateFlow()

    val isFirebaseAvailable: Boolean
        get() = try {
            FirebaseApp.getApps(context).isNotEmpty()
        } catch (e: Throwable) {
            false
        }

    fun getCelularesFlow(): Flow<List<Celular>> = callbackFlow {
        if (isFirebaseAvailable) {
            var registration: ListenerRegistration? = null
            try {
                val db = FirebaseFirestore.getInstance()
                registration = db.collection("celulares")
                    .orderBy("fechaRegistro", Query.Direction.DESCENDING)
                    .addSnapshotListener { snapshot, error ->
                        if (error != null) {
                            Log.w("CelularesRepo", "Firestore listen failed, using local cache", error)
                            trySend(_localCelulares.value)
                            return@addSnapshotListener
                        }

                        if (snapshot != null && !snapshot.isEmpty) {
                            val list = snapshot.documents.map { doc ->
                                val data = doc.data ?: emptyMap()
                                Celular.fromMap(doc.id, data)
                            }
                            // Also update local cache
                            saveStoredPhones(list)
                            _localCelulares.value = list
                            trySend(list)
                        } else {
                            // If empty in cloud, send local defaults/added
                            trySend(_localCelulares.value)
                        }
                    }

                awaitClose { registration?.remove() }
                return@callbackFlow
            } catch (e: Throwable) {
                Log.w("CelularesRepo", "Firestore init failed", e)
            }
        }

        // Offline / Local Mode
        trySend(_localCelulares.value)
        awaitClose { }
    }

    suspend fun agregarCelular(celular: Celular): Result<Celular> {
        val newCelular = if (celular.id.isBlank()) {
            celular.copy(id = "cel_${System.currentTimeMillis()}")
        } else {
            celular
        }

        if (isFirebaseAvailable) {
            try {
                val db = FirebaseFirestore.getInstance()
                val docRef = db.collection("celulares").add(newCelular.toMap()).await()
                val created = newCelular.copy(id = docRef.id)
                val updated = listOf(created) + _localCelulares.value.filter { it.id != created.id }
                _localCelulares.value = updated
                saveStoredPhones(updated)
                return Result.success(created)
            } catch (e: Exception) {
                Log.e("CelularesRepo", "Error adding to Firestore", e)
                // Continue to save locally if cloud fails
            }
        }

        // Local save
        val updated = listOf(newCelular) + _localCelulares.value.filter { it.id != newCelular.id }
        _localCelulares.value = updated
        saveStoredPhones(updated)
        return Result.success(newCelular)
    }

    suspend fun buscarPorImei(imeiQuery: String): List<Celular> {
        val cleanQuery = imeiQuery.trim()
        if (cleanQuery.isEmpty()) return _localCelulares.value

        if (isFirebaseAvailable) {
            try {
                val db = FirebaseFirestore.getInstance()
                val snapshot = db.collection("celulares")
                    .whereEqualTo("imei", cleanQuery)
                    .get()
                    .await()

                if (!snapshot.isEmpty) {
                    return snapshot.documents.map { Celular.fromMap(it.id, it.data ?: emptyMap()) }
                }
            } catch (e: Exception) {
                Log.w("CelularesRepo", "Firestore IMEI query error", e)
            }
        }

        // Local search (supports exact or partial match)
        return _localCelulares.value.filter {
            it.imei.contains(cleanQuery, ignoreCase = true)
        }
    }

    suspend fun marcarComoRecuperado(celularId: String): Result<Unit> {
        if (isFirebaseAvailable) {
            try {
                val db = FirebaseFirestore.getInstance()
                db.collection("celulares").document(celularId).update("estado", "Recuperado").await()
            } catch (e: Exception) {
                Log.w("CelularesRepo", "Firestore update failed", e)
            }
        }

        val updated = _localCelulares.value.map {
            if (it.id == celularId) it.copy(estado = "Recuperado") else it
        }
        _localCelulares.value = updated
        saveStoredPhones(updated)
        return Result.success(Unit)
    }

    private fun loadStoredPhones(): List<Celular> {
        val json = prefs.getString("celulares_list", null)
        if (!json.isNullOrBlank()) {
            try {
                val array = JSONArray(json)
                val list = mutableListOf<Celular>()
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    list.add(
                        Celular(
                            id = obj.optString("id"),
                            marca = obj.optString("marca"),
                            modelo = obj.optString("modelo"),
                            imei = obj.optString("imei"),
                            color = obj.optString("color"),
                            contacto = obj.optString("contacto"),
                            fechaRegistro = obj.optLong("fechaRegistro", System.currentTimeMillis()),
                            estado = obj.optString("estado", "Perdido"),
                            descripcion = obj.optString("descripcion"),
                            usuarioEmail = obj.optString("usuarioEmail")
                        )
                    )
                }
                if (list.isNotEmpty()) return list
            } catch (e: Exception) {
                Log.e("CelularesRepo", "Failed to parse local stored phones", e)
            }
        }

        // Default seed data for initial discovery
        val defaultList = listOf(
            Celular(
                id = "seed_1",
                marca = "Samsung",
                modelo = "Galaxy S23 Ultra",
                imei = "864209041234567",
                color = "Negro Fantasma",
                contacto = "+54 9 11 5555-0192",
                fechaRegistro = System.currentTimeMillis() - 3600_000 * 5,
                estado = "Perdido",
                descripcion = "Perdido en cafetería centro. Funda de cuero negra.",
                usuarioEmail = "carlos.m@example.com"
            ),
            Celular(
                id = "seed_2",
                marca = "Apple",
                modelo = "iPhone 14 Pro",
                imei = "359876092345678",
                color = "Morado Oscuro",
                contacto = "+54 9 11 4444-8833",
                fechaRegistro = System.currentTimeMillis() - 3600_000 * 24,
                estado = "Perdido",
                descripcion = "Extraviado en línea D del subte. Pantalla con protector.",
                usuarioEmail = "maria.g@example.com"
            ),
            Celular(
                id = "seed_3",
                marca = "Xiaomi",
                modelo = "Redmi Note 12",
                imei = "867345093456789",
                color = "Azul Hielo",
                contacto = "+54 9 11 3333-2211",
                fechaRegistro = System.currentTimeMillis() - 3600_000 * 48,
                estado = "Perdido",
                descripcion = "Olvidad en plaza cerca de los juegos.",
                usuarioEmail = "juan.p@example.com"
            ),
            Celular(
                id = "seed_4",
                marca = "Motorola",
                modelo = "Moto Edge 40 Neo",
                imei = "354123094567890",
                color = "Verde Caña",
                contacto = "+54 9 11 7777-9900",
                fechaRegistro = System.currentTimeMillis() - 3600_000 * 72,
                estado = "Recuperado",
                descripcion = "Recuperado exitosamente gracias a RecuperaTuCelu.",
                usuarioEmail = "ana.s@example.com"
            )
        )
        saveStoredPhones(defaultList)
        return defaultList
    }

    private fun saveStoredPhones(list: List<Celular>) {
        try {
            val array = JSONArray()
            for (item in list) {
                val obj = JSONObject().apply {
                    put("id", item.id)
                    put("marca", item.marca)
                    put("modelo", item.modelo)
                    put("imei", item.imei)
                    put("color", item.color)
                    put("contacto", item.contacto)
                    put("fechaRegistro", item.fechaRegistro)
                    put("estado", item.estado)
                    put("descripcion", item.descripcion)
                    put("usuarioEmail", item.usuarioEmail)
                }
                array.put(obj)
            }
            prefs.edit().putString("celulares_list", array.toString()).apply()
        } catch (e: Exception) {
            Log.e("CelularesRepo", "Error saving stored phones", e)
        }
    }
}
