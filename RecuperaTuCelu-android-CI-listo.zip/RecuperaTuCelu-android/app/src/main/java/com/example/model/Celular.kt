package com.example.model

data class Celular(
    val id: String = "",
    val marca: String = "",
    val modelo: String = "",
    val imei: String = "",
    val color: String = "",
    val contacto: String = "",
    val fechaRegistro: Long = System.currentTimeMillis(),
    val estado: String = "Perdido", // "Perdido", "Recuperado"
    val descripcion: String = "",
    val usuarioEmail: String = ""
) {
    fun toMap(): Map<String, Any> {
        return mapOf(
            "marca" to marca,
            "modelo" to modelo,
            "imei" to imei,
            "color" to color,
            "contacto" to contacto,
            "fechaRegistro" to fechaRegistro,
            "estado" to estado,
            "descripcion" to descripcion,
            "usuarioEmail" to usuarioEmail
        )
    }

    companion object {
        fun fromMap(id: String, map: Map<String, Any?>): Celular {
            return Celular(
                id = id,
                marca = (map["marca"] as? String).orEmpty(),
                modelo = (map["modelo"] as? String).orEmpty(),
                imei = (map["imei"] as? String).orEmpty(),
                color = (map["color"] as? String).orEmpty(),
                contacto = (map["contacto"] as? String).orEmpty(),
                fechaRegistro = (map["fechaRegistro"] as? Long)
                    ?: (map["fechaRegistro"] as? Number)?.toLong()
                    ?: System.currentTimeMillis(),
                estado = (map["estado"] as? String) ?: "Perdido",
                descripcion = (map["descripcion"] as? String).orEmpty(),
                usuarioEmail = (map["usuarioEmail"] as? String).orEmpty()
            )
        }
    }
}
