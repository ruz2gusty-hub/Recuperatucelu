package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Celular
import com.example.ui.RecuperaTuCeluViewModel
import com.example.ui.UiMessage
import com.example.ui.theme.AccentAmber
import com.example.ui.theme.AccentRed
import com.example.ui.theme.BadgeLostBg
import com.example.ui.theme.BadgeLostText
import com.example.ui.theme.BadgeRecoveredBg
import com.example.ui.theme.BadgeRecoveredText
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.OnPrimaryDark
import com.example.ui.theme.OutlineColor
import com.example.ui.theme.PrimaryCyan
import com.example.ui.theme.PrimaryCyanLight
import com.example.ui.theme.SecondaryEmerald
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(viewModel: RecuperaTuCeluViewModel) {
    val user by viewModel.currentUser.collectAsState()
    val celulares by viewModel.filteredCelulares.collectAsState()
    val allCelulares by viewModel.celularesList.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val selectedFilter by viewModel.selectedFilter.collectAsState()
    val uiMessage by viewModel.uiMessage.collectAsState()

    val showAddDialog by viewModel.showAddDialog.collectAsState()
    val showImeiCheckDialog by viewModel.showImeiCheckDialog.collectAsState()
    val selectedPhone by viewModel.selectedPhone.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }
    val clipboardManager = LocalClipboardManager.current
    val context = LocalContext.current

    LaunchedEffect(uiMessage) {
        uiMessage?.let { msg ->
            when (msg) {
                is UiMessage.Success -> snackbarHostState.showSnackbar(msg.message)
                is UiMessage.Error -> snackbarHostState.showSnackbar(msg.message)
            }
            viewModel.clearUiMessage()
        }
    }

    val totalCount = allCelulares.size
    val lostCount = allCelulares.count { it.estado.equals("Perdido", ignoreCase = true) }
    val recoveredCount = allCelulares.count { it.estado.equals("Recuperado", ignoreCase = true) }

    var selectedBottomNav by remember { mutableStateOf(0) }

    Scaffold(
        containerColor = DarkBackground,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DarkBackground,
                    titleContentColor = TextPrimary
                ),
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Geometric Balance Monogram Avatar
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(DarkSurfaceVariant),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "R",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 20.sp
                                ),
                                color = PrimaryCyan
                            )
                        }
                        Column {
                            Text(
                                text = "RecuperaTuCelu",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Medium,
                                    letterSpacing = 0.5.sp
                                ),
                                color = TextPrimary
                            )
                            Text(
                                text = if (viewModel.isCloudConnected) "Firestore: celulares" else "Modo Local Activo",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (viewModel.isCloudConnected) PrimaryCyanLight else SecondaryEmerald
                            )
                        }
                    }
                },
                actions = {
                    // User indicator & Logout
                    user?.let { u ->
                        Surface(
                            shape = CircleShape,
                            color = DarkSurfaceVariant,
                            modifier = Modifier.padding(end = 4.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Person,
                                    contentDescription = null,
                                    tint = PrimaryCyan,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = u.email.substringBefore("@"),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }

                    IconButton(
                        onClick = { viewModel.logout() },
                        modifier = Modifier.testTag("btn_logout")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ExitToApp,
                            contentDescription = "Cerrar sesión",
                            tint = TextSecondary
                        )
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { viewModel.openAddDialog() },
                containerColor = PrimaryCyan,
                contentColor = OnPrimaryDark,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .size(56.dp)
                    .testTag("fab_reportar")
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Reportar Celular",
                    modifier = Modifier.size(28.dp),
                    tint = OnPrimaryDark
                )
            }
        },
        bottomBar = {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(76.dp),
                color = DarkSurface,
                border = androidx.compose.foundation.BorderStroke(1.dp, OutlineColor)
            ) {
                Row(
                    modifier = Modifier.fillMaxSize(),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Tab 1: Inicio
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .weight(1f)
                            .clickable {
                                selectedBottomNav = 0
                                viewModel.selectedFilter.value = "Todos"
                            }
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = if (selectedBottomNav == 0) DarkSurfaceVariant else Color.Transparent,
                            modifier = Modifier.padding(bottom = 2.dp)
                        ) {
                            Box(modifier = Modifier.padding(horizontal = 18.dp, vertical = 4.dp)) {
                                Icon(
                                    imageVector = Icons.Default.Home,
                                    contentDescription = "Inicio",
                                    tint = if (selectedBottomNav == 0) PrimaryCyan else TextSecondary,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                        Text(
                            text = "Inicio",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium),
                            color = if (selectedBottomNav == 0) TextPrimary else TextSecondary
                        )
                    }

                    // Tab 2: Buscar
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .weight(1f)
                            .clickable {
                                selectedBottomNav = 1
                            }
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = if (selectedBottomNav == 1) DarkSurfaceVariant else Color.Transparent,
                            modifier = Modifier.padding(bottom = 2.dp)
                        ) {
                            Box(modifier = Modifier.padding(horizontal = 18.dp, vertical = 4.dp)) {
                                Icon(
                                    imageVector = Icons.Default.Search,
                                    contentDescription = "Buscar",
                                    tint = if (selectedBottomNav == 1) PrimaryCyan else TextSecondary,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                        Text(
                            text = "Buscar",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium),
                            color = if (selectedBottomNav == 1) TextPrimary else TextSecondary
                        )
                    }

                    // Tab 3: Verificar IMEI
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .weight(1f)
                            .clickable {
                                selectedBottomNav = 2
                                viewModel.imeiCheckInput.value = ""
                                viewModel.hasCheckedImei.value = false
                                viewModel.imeiCheckResult.value = null
                                viewModel.showImeiCheckDialog.value = true
                            }
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = if (selectedBottomNav == 2) DarkSurfaceVariant else Color.Transparent,
                            modifier = Modifier.padding(bottom = 2.dp)
                        ) {
                            Box(modifier = Modifier.padding(horizontal = 18.dp, vertical = 4.dp)) {
                                Icon(
                                    imageVector = Icons.Default.Shield,
                                    contentDescription = "Verificar",
                                    tint = if (selectedBottomNav == 2) PrimaryCyan else TextSecondary,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                        Text(
                            text = "Verificar",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium),
                            color = if (selectedBottomNav == 2) TextPrimary else TextSecondary
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Stats Overview Banner
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    StatCard(
                        title = "Reportados",
                        value = "$totalCount",
                        color = PrimaryCyan,
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        title = "Perdidos",
                        value = "$lostCount",
                        color = AccentAmber,
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        title = "Recuperados",
                        value = "$recoveredCount",
                        color = SecondaryEmerald,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Quick IMEI Verifier Action Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            viewModel.imeiCheckInput.value = ""
                            viewModel.hasCheckedImei.value = false
                            viewModel.imeiCheckResult.value = null
                            viewModel.showImeiCheckDialog.value = true
                        }
                        .testTag("card_verificar_imei"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant),
                    border = androidx.compose.foundation.BorderStroke(1.dp, PrimaryCyan.copy(alpha = 0.4f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(PrimaryCyan.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Default.Shield,
                                    contentDescription = null,
                                    tint = PrimaryCyan,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "Verificador Oficial de IMEI",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "¿Vas a comprar un celu? Consulta si tiene reporte",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Icon(
                            Icons.Default.Search,
                            contentDescription = "Consultar",
                            tint = PrimaryCyan,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            // Search Bar & Filter Chips
            item {
                Column(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { viewModel.searchQuery.value = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("search_imei_input"),
                        placeholder = { Text("Buscar por IMEI...", color = TextSecondary) },
                        leadingIcon = {
                            Icon(Icons.Default.Search, contentDescription = "Buscar", tint = TextSecondary)
                        },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { viewModel.searchQuery.value = "" }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Limpiar", tint = TextSecondary)
                                }
                            }
                        },
                        singleLine = true,
                        shape = CircleShape,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = DarkSurface,
                            unfocusedContainerColor = DarkSurface,
                            focusedBorderColor = PrimaryCyan,
                            unfocusedBorderColor = OutlineColor,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Filters
                    val filterOptions = listOf("Todos", "Perdidos", "Recuperados", "Mis Reportes")
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        filterOptions.forEach { filter ->
                            FilterChip(
                                selected = selectedFilter == filter,
                                onClick = { viewModel.selectedFilter.value = filter },
                                label = { Text(filter) },
                                shape = CircleShape,
                                colors = FilterChipDefaults.filterChipColors(
                                    containerColor = DarkSurface,
                                    labelColor = TextSecondary,
                                    selectedContainerColor = DarkSurfaceVariant,
                                    selectedLabelColor = PrimaryCyan
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    enabled = true,
                                    selected = selectedFilter == filter,
                                    borderColor = if (selectedFilter == filter) PrimaryCyan else OutlineColor
                                )
                            )
                        }
                    }
                }
            }

            // Header for List (Geometric Balance Typography)
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp, start = 4.dp, end = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "CELULARES REPORTADOS",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.SemiBold,
                            letterSpacing = 1.sp
                        ),
                        color = PrimaryCyan
                    )
                    Text(
                        text = "${celulares.size} Resultados",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                }
            }

            // List of Phones
            if (celulares.isEmpty()) {
                item {
                    EmptyStateCard(
                        hasQuery = searchQuery.isNotBlank(),
                        onClearSearch = { viewModel.searchQuery.value = "" },
                        onReportClick = { viewModel.openAddDialog() }
                    )
                }
            } else {
                items(celulares, key = { it.id }) { celular ->
                    CelularCard(
                        celular = celular,
                        onClick = { viewModel.selectedPhone.value = celular },
                        onCopyImei = {
                            clipboardManager.setText(AnnotatedString(celular.imei))
                            viewModel.uiMessage.value = UiMessage.Success("IMEI ${celular.imei} copiado")
                        },
                        onContactClick = {
                            val digits = celular.contacto.filter { it.isDigit() || it == '+' }
                            val intent = Intent(Intent.ACTION_DIAL).apply {
                                data = Uri.parse("tel:$digits")
                            }
                            try { context.startActivity(intent) } catch (e: Exception) {}
                        }
                    )
                }
            }

            // Bottom space for FAB
            item {
                Spacer(modifier = Modifier.height(72.dp))
            }
        }
    }

    // Dialogs
    if (showAddDialog) {
        AddPhoneDialog(viewModel = viewModel)
    }

    if (showImeiCheckDialog) {
        ImeiCheckDialog(viewModel = viewModel)
    }

    selectedPhone?.let { phone ->
        PhoneDetailDialog(
            celular = phone,
            viewModel = viewModel,
            onDismiss = { viewModel.selectedPhone.value = null }
        )
    }
}

@Composable
fun StatCard(
    title: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = DarkSurface,
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, OutlineColor)
    ) {
        Column(
            modifier = Modifier.padding(vertical = 12.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold),
                color = color
            )
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary
            )
        }
    }
}

@Composable
fun CelularCard(
    celular: Celular,
    onClick: () -> Unit,
    onCopyImei: () -> Unit,
    onContactClick: () -> Unit
) {
    val isRecovered = celular.estado.equals("Recuperado", ignoreCase = true)
    val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
    val dateStr = dateFormat.format(Date(celular.fechaRegistro))

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("card_celular_${celular.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, OutlineColor)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Header: Model/Brand on left, Status Pill on right
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                    Text(
                        text = "${celular.marca} ${celular.modelo}",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Medium,
                            fontSize = 17.sp
                        ),
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "${celular.color} • $dateStr",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }

                // Geometric Balance Pill Badge
                Surface(
                    shape = CircleShape,
                    color = if (isRecovered) BadgeRecoveredBg else BadgeLostBg
                ) {
                    Text(
                        text = if (isRecovered) "RECUPERADO" else "ROBADO",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            letterSpacing = 0.5.sp
                        ),
                        color = if (isRecovered) BadgeRecoveredText else BadgeLostText,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            // IMEI Capsule in DarkSurfaceVariant (#4A4458)
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = DarkSurfaceVariant
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "IMEI: ${celular.imei}",
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Medium,
                                fontSize = 11.sp
                            ),
                            color = PrimaryCyan
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Copiar IMEI",
                            tint = PrimaryCyan,
                            modifier = Modifier
                                .size(14.dp)
                                .clickable { onCopyImei() }
                        )
                    }
                }
            }

            // Contact info with quick dial button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Contacto: ${celular.contacto}",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextPrimary.copy(alpha = 0.85f),
                    modifier = Modifier.weight(1f)
                )

                Surface(
                    shape = CircleShape,
                    color = DarkSurfaceVariant,
                    modifier = Modifier.clickable { onContactClick() }
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    ) {
                        Icon(
                            Icons.Default.Phone,
                            contentDescription = "Llamar",
                            tint = SecondaryEmerald,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Contactar",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = SecondaryEmerald
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun EmptyStateCard(
    hasQuery: Boolean,
    onClearSearch: () -> Unit,
    onReportClick: () -> Unit
) {
    Surface(
        color = DarkSurface,
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = if (hasQuery) Icons.Default.Search else Icons.Default.PhoneAndroid,
                contentDescription = null,
                tint = PrimaryCyan,
                modifier = Modifier.size(48.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = if (hasQuery) "No se encontraron celulares" else "No hay reportes registrados",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface,
                textAlign = TextAlign.Center
            )
            Text(
                text = if (hasQuery) "Intenta con otro número de IMEI, marca o modelo." else "Sé el primero en registrar un celular perdido para iniciar la red de búsqueda.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 4.dp, bottom = 14.dp)
            )

            if (hasQuery) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = DarkSurfaceVariant,
                    modifier = Modifier.clickable { onClearSearch() }
                ) {
                    Text(
                        text = "Limpiar búsqueda",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        color = PrimaryCyan,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                }
            } else {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = PrimaryCyan,
                    modifier = Modifier.clickable { onReportClick() }
                ) {
                    Text(
                        text = "Reportar Celular Ahora",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        color = Color.Black,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                }
            }
        }
    }
}
